﻿using System;
/** 
 * Name: Tao Ji Yang
 * Courses: NMAD.180:PROGRAMMING FUNDAMENTALS I:MOBILE DOMAIN
 * Due Date; 2/10/2021
 * Purpose: Being able to do mini short programming, input for student name and also show how two test divide by two. 
 * Caveats: #16 string was a lot of struggle because I couldn't add CW without adding double.parse. So I basically have to convert string data into double. Because string.Parse did not work. I tried lol.
 */
namespace VS
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("What is the student name?: ");
            string studentName = Console.ReadLine();
            //double StudentName = double.Parse(studentName)// //I thought I need it because I was trying to convert the value to, but I reaalized that every time string convert to double, it doesn't make sense because I was trying to use double.Parse so that line number 29 can read line 16 more better. But I realize removing this line 17 was the main issues why the whole code wasn't working. 

            Console.WriteLine("Please give me the result for your first test score: ");

            int test1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Please give me the result for your second test score: ");
            int test2 = int.Parse(Console.ReadLine());


            double twoTESTAverage = (test1 + test2) / 2;

            Console.WriteLine("Student: " + studentName);
            Console.WriteLine("Test 1: " +test1);
            Console.WriteLine("Test 2: " + test2);
            Console.WriteLine("Average: " + twoTESTAverage);



        }
    }
}
